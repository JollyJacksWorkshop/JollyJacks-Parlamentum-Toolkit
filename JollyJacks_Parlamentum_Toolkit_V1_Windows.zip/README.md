# JollyJack's Parlamentum Toolkit V1

An offline desktop/browser planning toolkit for the Parlamentum game. This is the first **full version**, following the earlier navigation prototypes.

## Get started

### Windows application (recommended)
1. Extract `JollyJacks_Parlamentum_Toolkit_V1_Windows.zip` into a folder on your computer.
2. Double-click `JollyJacks_Parlamentum_Toolkit_V1.exe`.
3. The application opens automatically in your default browser, using a local address such as `http://127.0.0.1:54321/`. **It does not connect to Parlamentum or an external server.** Keep the executable running while using the interface.
4. On the first launch, all player-specific records are empty. You can add your own countries, regions, workers, companies, and supply chains.
5. Windows application data is saved to your account's application configuration folder (typically `%APPDATA%\JollyJacksParlamentumToolkit\settings.json`). The application also supports JSON backup export.

If Windows prompts you to allow the unrecognized executable, it is an unsigned, self-built program; do not bypass security warnings without verifying the file's origin and content. The provided source code can be inspected and rebuilt.

### Browser-only version
Open `JollyJacks_Parlamentum_Toolkit_V1.html` directly in Chrome, Firefox, Edge, or Opera. No installation or internet connection is required. Browser data is saved in local browser storage; the storage is tied to the file origin, so moving the file, changing browsers, clearing site data or private browsing can make it unavailable. Export a JSON backup periodically. Browser storage limits can prevent saving many large image logos.

## Main areas

- **Dashboard:** Counts start at zero; no example records are loaded.
- **My Profile:** Add an avatar, name, character level, Economy/Education/War skills, and a home country; save or discard changes.
- **Countries:** Add names, flags, currency values, tax rates and policies. Unknown numeric values stay blank.
- **Regions:** Add independent regional deposits and Health, Education, Military, Industry, Electricity levels. Change the controlling country any time; linked companies inherit it.
- **My Companies:** Resource Plant (Raw Grain, Raw Iron, Raw Oil, Raw Cotton, Timber, Coal, Raw Copper), Factory (Food, Weapon, Ticket; T1–T5), Light Industry (Construction Materials, Fuel, Electronics), Heavy Industry (Ships; T1–T5). Upload/remove independent company logos; assign linked or company-only workers, region, and company level.
- **Workers:** Save reusable workers with individual skills, energy, and wage details. Private company workers are supported too.
- **Supply Chains:** Name multiple workspaces; add saved company blocks from a searchable picker, storage and market blocks; drag and connect blocks; collapse either or both side panels; edit block-specific inputs and advanced scenario settings; calculate supply-chain output, payroll, taxes and sales; save, duplicate, load, export, and import JSON.
- **Templates:** Save, load, import and export reuseable supply-chain setups.
- **Calculator Library (9 calculators):** Production, Payroll & Wages, Markets & Exports, Iron → Weapons, Gold ↔ Cash, Combat Damage, Company Upgrades, Stat Training, and Energy Planner. Includes editable inputs and visual graphs where useful.
- **Settings:** Preferences and whole-database import/export backup.

## Important model limitations

- This toolkit provides **estimated** calculations from entered stats and published game rules, not live game account information or market quotes.
- It does **not** automatically log into Parlamentum, retrieve market prices, update territory ownership, or make trades.
- Where required fields are blank, outputs may be unavailable or marked as estimates. A blank value means unknown, not zero.
- Simulation models configured shifts and resource consumption but does not guarantee actual gameplay results. Depending on game updates or exceptions, published rules may differ.
- No financial or product sale is guaranteed; the app assumes that entered quantities can be sold at entered prices when evaluating revenue.
- Advanced simulation is an offline planning approximation, not a full time-stepped, live-world economic engine.

## Save, load, export and import

Use the Supply Chains section to name and manage each chain. `Export JSON` creates an independent portable snapshot of the layout, price inputs, allocation settings and any necessary linked company information. Use `Import JSON` to bring it into the toolkit. A workspace can be saved as a template for reuse. `Settings` offers a full profile/database backup, which is especially useful when moving between computers or browsers.

## Build from source (optional)

The source bundle contains a fully offline HTML application, its JS/CSS calculation engine, Go Windows launcher, and tests.

Prerequisites: Go 1.23+ (for Windows executable), Node.js (for engine unit tests), Python + Playwright for browser smoke tests.

```sh
# Build the application HTML
python build.py

# Run engine unit tests
node tests/engine.test.js

# Build Windows .exe from source on any host with Go installed
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w -H=windowsgui" -o JollyJacks_Parlamentum_Toolkit_V1.exe .
```

The supplied `assets/index.html` is already a self-contained offline application. You do not need to run `build.py` to use it. The `build.py` script refers to a brand asset and the checked-in SVG icon source; only run it if all bundled inputs are present. When editing the standalone app code, update the embedded `assets/index.html` before rebuilding the executable.

All game-specific data remains owned by the local user. Artwork and company names are only used where the user provided them.
